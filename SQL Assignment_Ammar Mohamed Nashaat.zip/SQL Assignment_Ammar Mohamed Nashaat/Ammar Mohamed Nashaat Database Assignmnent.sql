CREATE DATABASE IF NOT EXISTS seatRes;
USE seatRes;
CREATE TABLE IF NOT EXISTS Movies (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    duration INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);
CREATE TABLE IF NOT EXISTS Halls (
    hall_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS CreditCards (
    card_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    card_number VARCHAR(255) NOT NULL,
    expiry_date DATE NOT NULL,
    cvv INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);
CREATE TABLE IF NOT EXISTS Seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    seat_number VARCHAR(255) NOT NULL,
    movie_id INT NOT NULL,
    hall_id INT NOT NULL,
    is_booked BOOLEAN DEFAULT 0,
    FOREIGN KEY (movie_id) REFERENCES Movies(movie_id),
    FOREIGN KEY (hall_id) REFERENCES Halls(hall_id)
);
CREATE TABLE IF NOT EXISTS Reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    movie_id INT NOT NULL,
    seat_id INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (movie_id) REFERENCES Movies(movie_id),
    FOREIGN KEY (seat_id) REFERENCES Seats(seat_id)
);
INSERT INTO Halls (name, location) VALUES 
('Main Hall', 'First Floor'),
('VIP Hall', 'Second Floor');
-- Insert sample movies with prices and durations
INSERT INTO Movies (title, price, duration) VALUES 
('The Shawshank Redemption', 10.99, 142),
('The Godfather', 12.50, 175),
('The Dark Knight', 11.75, 152),
('Pulp Fiction', 9.99, 154),
('Schindler''s List', 11.25, 195),
('Forrest Gump', 10.50, 142);
INSERT INTO Seats (hall_id, movie_id, seat_number)
SELECT h.hall_id, m.movie_id, CONCAT('Seat', LPAD(n.n, 2, '0')) AS seat_number
FROM Halls h
CROSS JOIN Movies m
CROSS JOIN (
    SELECT 1 AS n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL
    SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL
    SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL
    SELECT 16 UNION ALL SELECT 17 UNION ALL SELECT 18 UNION ALL SELECT 19 UNION ALL SELECT 20 UNION ALL
    SELECT 21 UNION ALL SELECT 22 UNION ALL SELECT 23 UNION ALL SELECT 24 UNION ALL SELECT 25 UNION ALL
    SELECT 26 UNION ALL SELECT 27 UNION ALL SELECT 28 UNION ALL SELECT 29 UNION ALL SELECT 30 UNION ALL
    SELECT 31 UNION ALL SELECT 32 UNION ALL SELECT 33 UNION ALL SELECT 34 UNION ALL SELECT 35 UNION ALL
    SELECT 36 UNION ALL SELECT 37 UNION ALL SELECT 38 UNION ALL SELECT 39 UNION ALL SELECT 40 UNION ALL
    SELECT 41 UNION ALL SELECT 42 UNION ALL SELECT 43 UNION ALL SELECT 44 UNION ALL SELECT 45 UNION ALL
    SELECT 46 UNION ALL SELECT 47 UNION ALL SELECT 48 UNION ALL SELECT 49 UNION ALL SELECT 50
) n;
CREATE VIEW MovieDetails AS
SELECT movie_id, title, price, duration
FROM Movies;
CREATE VIEW AllReservations AS
SELECT r.reservation_id, c.name AS customer_name, c.phone AS customer_phone, m.title AS movie_title, h.name AS hall_name, s.seat_number
FROM Reservations r
JOIN Customers c ON r.customer_id = c.customer_id
JOIN Movies m ON r.movie_id = m.movie_id
JOIN Seats s ON r.seat_id = s.seat_id
JOIN Halls h ON s.hall_id = h.hall_id;
CREATE VIEW FreeSeatsForAllMovies AS
SELECT m.title AS movie_title, h.name AS hall_name, s.seat_number
FROM Seats s
JOIN Movies m ON s.movie_id = m.movie_id
JOIN Halls h ON s.hall_id = h.hall_id
WHERE s.is_booked = 0;
CREATE VIEW CreditCardDetails AS
SELECT c.name AS customer_name, cc.card_number, cc.expiry_date, cc.cvv
FROM CreditCards cc
JOIN Customers c ON cc.customer_id = c.customer_id;
CREATE VIEW HallDetails AS
SELECT h.hall_id, h.name AS hall_name, h.location
FROM Halls h;
DELIMITER //
CREATE PROCEDURE UpdatePhoneNumber(IN p_name VARCHAR(255), IN p_new_phone VARCHAR(255))
BEGIN
    UPDATE Customers
    SET phone = p_new_phone
    WHERE name = p_name;
END //
DELIMITER ;
DELIMITER //
CREATE PROCEDURE DeleteReservation(IN reservationId INT)
BEGIN
    DECLARE seatId INT;
    SELECT seat_id INTO seatId
    FROM Reservations
    WHERE reservation_id = reservationId;
    IF seatId IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Reservation not found';
    END IF;
    DELETE FROM Reservations
    WHERE reservation_id = reservationId;
    UPDATE Seats
    SET is_booked = 0
    WHERE seat_id = seatId;
END //
DELIMITER ;